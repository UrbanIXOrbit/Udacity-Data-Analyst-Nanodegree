Part II - Insight into Ford GoBike System dataset
by Adelana Emmanuel


 Dataset

The Ford GoBike System Data dataset contains information about bike rides in a bike-sharing system covering the greater San Francisco Bay area. The dataset is one of the Udacity's curated dataset for the Data Analyst Nanodegree. The Ford GoBike system data has 18,3412 unique observations with 16 attributes with information on bike_id, users, ride duration and bike stations.


 Summary of Findings

1) The distribution of bike riding in hours has the mean of 0.19hrs with outliers as high as 23hrs.
2) Among the bike riders we have more males than females and more females than others.
3) The bike users are categorized into two; subscribers and customers, with more subscribers.
4) Majority of the bike users are born between the year 1960 and 2000.
5) The most used starting and ending station are Market St. at 10th St. and San Francisco Caltrain Station 2 respectively.
6) The least used starting and ending station are 16th St. Depot and Willow Sr at Vine St. respectively.
7) There is a negative correlation between duration of bike ride and member year of birth.
8) The male gender have the highest total bike riding time followed by the female gender followed by other.
9) The average riding time of customer is higher than the subscribers.
10) The total number of ride by subscribers is higher than customers.
11) The average bike riding time by the 'other' is higher than that of the female, with the male being the least.


 Key Insights for Presentation


The insight that will be presented will be drawn from the user type as a primary variable.

1) The user type is divided into two categories. For our bike sharing system the average duration of riding of customer is higer than that of subscribers.
2) The male gender have the highest total number of riding time followed by the female and by other.
3) For days of the week vis-a-vis user type, the subscribers have higher total number of rides accross the days of the week.
4) For average ride duration by usertype and member gender. Despite the fact that subscribers have higer total number of ride accross the days of the week the customers have higer average time in hours of riding than subscribers across the three gender.

Changes in our Charts:
1) The background theme of the plots was set to darkgrid.
2) The figure size of the plot was changed.
3) We choose a better color palette for the visualizations.